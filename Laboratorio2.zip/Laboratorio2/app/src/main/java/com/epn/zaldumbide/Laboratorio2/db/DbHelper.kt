package com.epn.zaldumbide.Laboratorio2.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// Esta clase crea la base de datos y la tabla física
class DbHelper(context: Context) : SQLiteOpenHelper(context, "Agenda.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase?) {
        // Aquí escribimos la sentencia SQL para crear la tabla
        val sql = "CREATE TABLE usuarios (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, apellido TEXT, cedula TEXT)"
        db?.execSQL(sql)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Esto se usa si cambias la versión de la base de datos en el futuro
        db?.execSQL("DROP TABLE IF EXISTS usuarios")
        onCreate(db)
    }
}