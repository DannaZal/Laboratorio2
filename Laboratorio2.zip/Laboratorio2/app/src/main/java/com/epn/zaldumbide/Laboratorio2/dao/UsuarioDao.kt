package com.epn.zaldumbide.Laboratorio2.dao

import android.content.ContentValues
import android.content.Context
import com.epn.zaldumbide.Laboratorio2.db.DbHelper
import com.epn.zaldumbide.Laboratorio2.modelo.ModeloUsuario

class UsuarioDao(context: Context) {

    // Instanciamos la conexión
    private val dbHelper = DbHelper(context)

    // --- FUNCIÓN 1: GUARDAR ---
    fun insertarUsuario(usuario: ModeloUsuario): Long {
        // Abrimos la base de datos en modo escritura
        val db = dbHelper.writableDatabase

        // Preparamos los valores (como un mapa llave-valor)
        val valores = ContentValues().apply {
            put("nombre", usuario.nombre)
            put("apellido", usuario.apellido)
            put("cedula", usuario.cedula)
        }

        // Insertamos y guardamos el resultado (ID de la fila creada)
        val resultado = db.insert("usuarios", null, valores)
        db.close() // Siempre cerrar la conexión
        return resultado
    }

    // --- FUNCIÓN 2: LISTAR (MOSTRAR) ---
    fun obtenerUsuarios(): ArrayList<ModeloUsuario> {
        val lista = ArrayList<ModeloUsuario>()
        // Abrimos la base de datos en modo lectura
        val db = dbHelper.readableDatabase

        // Hacemos la consulta SQL (SELECT * FROM usuarios)
        val cursor = db.rawQuery("SELECT * FROM usuarios", null)

        // Recorremos los resultados
        if (cursor.moveToFirst()) {
            do {
                // Sacamos los datos de las columnas (0, 1, 2, 3)
                val id = cursor.getInt(0)
                val nombre = cursor.getString(1)
                val apellido = cursor.getString(2)
                val cedula = cursor.getString(3)

                // Creamos el objeto y lo añadimos a la lista
                lista.add(ModeloUsuario(id, nombre, apellido, cedula))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return lista
    }

    // --- FUNCIÓN 3: ELIMINAR ---
    fun eliminarUsuario(id: Int): Int {
        val db = dbHelper.writableDatabase
        // Borramos donde el ID sea igual al que recibimos
        val filasAfectadas = db.delete("usuarios", "id=?", arrayOf(id.toString()))
        db.close()
        return filasAfectadas
    }
}