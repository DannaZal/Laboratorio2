package com.epn.zaldumbide.Laboratorio2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.epn.zaldumbide.Laboratorio2.adapter.UsuarioAdapter
import com.epn.zaldumbide.Laboratorio2.dao.UsuarioDao
import com.epn.zaldumbide.Laboratorio2.modelo.ModeloUsuario

class MainActivity : AppCompatActivity() {

    private lateinit var dao: UsuarioDao
    private lateinit var adapter: UsuarioAdapter
    private lateinit var listaUsuarios: ArrayList<ModeloUsuario>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. Inicializamos el DAO
        dao = UsuarioDao(this)

        // 2. Referencias a la vista (IDs deben coincidir con tu activity_main.xml)
        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etApellido = findViewById<EditText>(R.id.etApellido)
        val etCedula = findViewById<EditText>(R.id.etCedula)
        val btnGuardar = findViewById<Button>(R.id.btnGuardar)
        val listView = findViewById<ListView>(R.id.listViewPersonas)

        // 3. Función para mostrar la lista
        fun cargarLista() {
            listaUsuarios = dao.obtenerUsuarios()
            adapter = UsuarioAdapter(this, listaUsuarios)
            listView.adapter = adapter
        }

        // Cargamos la lista al iniciar la app
        cargarLista()

        // 4. Botón Guardar
        btnGuardar.setOnClickListener {
            val nombre = etNombre.text.toString()
            val apellido = etApellido.text.toString()
            val cedula = etCedula.text.toString()

            if (nombre.isNotEmpty() && apellido.isNotEmpty() && cedula.isNotEmpty()) {
                // Creamos el objeto (ID es 0 porque es autoincrementable)
                val nuevoUsuario = ModeloUsuario(0, nombre, apellido, cedula)

                val id = dao.insertarUsuario(nuevoUsuario)

                if (id > 0) {
                    Toast.makeText(this, "Guardado con éxito", Toast.LENGTH_SHORT).show()
                    // Limpiamos los campos
                    etNombre.text.clear()
                    etApellido.text.clear()
                    etCedula.text.clear()
                    etNombre.requestFocus()

                    // Recargamos la lista para ver el nuevo registro
                    cargarLista()
                } else {
                    Toast.makeText(this, "Error al guardar en BD", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Por favor llena todos los campos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}