package com.epn.zaldumbide.Laboratorio2.modelo

data class ModeloUsuario(
    val id: Int,
    val nombre: String,
    val apellido: String,
    val cedula: String
)