package com.epn.zaldumbide.Laboratorio2.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.epn.zaldumbide.Laboratorio2.R
import com.epn.zaldumbide.Laboratorio2.dao.UsuarioDao
import com.epn.zaldumbide.Laboratorio2.modelo.ModeloUsuario

class UsuarioAdapter(private val context: Context, private var lista: ArrayList<ModeloUsuario>) : BaseAdapter() {

    override fun getCount(): Int = lista.size
    override fun getItem(position: Int): Any = lista[position]
    override fun getItemId(position: Int): Long = lista[position].id.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val vista = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_persona, parent, false)

        val usuario = lista[position]

        // Referencias a los elementos visuales de item_persona.xml
        val tvDatos = vista.findViewById<TextView>(R.id.tvDatos)
        val btnEliminar = vista.findViewById<Button>(R.id.btnEliminar)

        tvDatos.text = "${usuario.nombre} ${usuario.apellido} \nCédula: ${usuario.cedula}"

        // --- LÓGICA DEL BOTÓN ELIMINAR ---
        btnEliminar.setOnClickListener {
            val dao = UsuarioDao(context)
            val resultado = dao.eliminarUsuario(usuario.id)

            if (resultado > 0) {
                Toast.makeText(context, "Eliminado correctamente", Toast.LENGTH_SHORT).show()
                // Actualizamos la lista visualmente removiendo el item
                lista.removeAt(position)
                notifyDataSetChanged()
            } else {
                Toast.makeText(context, "Error al eliminar", Toast.LENGTH_SHORT).show()
            }
        }

        return vista
    }
}